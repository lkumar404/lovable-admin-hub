import { Sampradaya, Saint, Book, Vani } from './types';

export const sampradayas: Sampradaya[] = [
  {
    id: 'harivanshi',
    name: 'Harivanshī (Rādhāvallabh)',
    nameHindi: 'हरिवंशी (राधावल्लभ)',
    slug: 'harivanshi',
    description: 'Founded by Śrī Hit Harivansh Mahāprabhu in the 16th century at Vṛndāvan, this sampradāya is devoted exclusively to the Nitya-Vihār of Śrī Rādhā-Kṛṣṇa. The Rādhāvallabh tradition holds Śrī Rādhā as the supreme deity, with Kṛṣṇa as Her eternal consort. Its literature, known as the Hit Catuṣṭī, forms the liturgical and theological foundation of the tradition.',
    lineage: 'Śrī Hit Harivansh → Śrī Vanmālī → Śrī Dhruvdās → Śrī Chacha Vṛndāvandās',
    tags: ['Rādhāvallabh', 'Nitya-Vihār', 'Vṛndāvan'],
  },
  {
    id: 'haridasi',
    name: 'Haridāsī',
    nameHindi: 'हरिदासी',
    slug: 'haridasi',
    description: 'The Haridāsī sampradāya was established by Svāmī Haridās, the great mystic musician-saint of Vṛndāvan. Known for its emphasis on the divine aesthetics of Rādhā-Kṛṣṇa\'s eternal play (Nitya-Vihār), the tradition produced a rich body of devotional poetry steeped in musical rāgas and the theology of divine love.',
    lineage: 'Svāmī Haridās → Vitthal Vipul → Nagari Dās',
    tags: ['Haridāsī', 'Dhrupad', 'Nitya-Vihār'],
  },
  {
    id: 'lalit',
    name: 'Lalit (Vanśī Alī Lineage)',
    nameHindi: 'ललित (वंशी अली)',
    slug: 'lalit',
    description: 'The Lalit sampradāya, tracing its origins through the Vanśī Alī lineage, emphasizes the Lalita-bhāva — the mood of intimate, playful divine service within the eternal pastimes of the Divine Couple. This tradition is known for its deeply esoteric devotional literature and its unique theological framework centered on the Sakhī-bhāva.',
    lineage: 'Vanśī Alī → Lalit Mohini → Tradition continues',
    tags: ['Lalit', 'Sakhī-bhāva', 'Esoteric'],
  },
];

export const saints: Saint[] = [
  {
    id: 'hit-harivansh',
    name: 'Śrī Hit Harivansh Mahāprabhu',
    nameHindi: 'श्री हित हरिवंश महाप्रभु',
    slug: 'hit-harivansh-mahaprabhu',
    sampradayaId: 'harivanshi',
    period: '1502–1552 CE',
    bio: 'Śrī Hit Harivansh Mahāprabhu is the founder-ācārya of the Rādhāvallabh Sampradāya and the revealer of the Rādhāvallabh temple at Vṛndāvan. Born in the village of Devbandh near Mathurā, he composed the sacred Hit Catuṣṭī — a collection of 84 verses that form the doctrinal and liturgical core of the tradition. His theology centers on the supremacy of Śrī Rādhā and the eternal, unbroken divine play (Nitya-Vihār) in the groves of Vṛndāvan.',
    works: ['Hit Catuṣṭī', 'Rādhā-Sudhanidhi (attributed)', 'Sphuṭ Vāṇī'],
    theologicalEmphasis: 'Supremacy of Śrī Rādhā, Nitya-Vihār, Prema-rasa as the ultimate spiritual goal',
    tags: ['Founder', 'Rādhāvallabh', 'Hit Catuṣṭī'],
  },
  {
    id: 'swami-haridas',
    name: 'Svāmī Haridās',
    nameHindi: 'स्वामी हरिदास',
    slug: 'swami-haridas',
    sampradayaId: 'haridasi',
    period: '1478–1573 CE',
    bio: 'Svāmī Haridās was a legendary poet-musician and mystic of Vṛndāvan, revered as the guru of Tānsen and the founder of the Haridāsī Sampradāya. His compositions, known as Kelimāl and Aṣṭādaśa Siddhāntpaddhati, reveal the theology of Nitya-Vihār through the language of music and aesthetic rapture. He is said to have manifested the deity of Bāṅke Bihārī through the intensity of his devotional absorption.',
    works: ['Kelimāl', 'Aṣṭādaśa Siddhāntpaddhati'],
    theologicalEmphasis: 'Divine aesthetics (Saundarya), Nitya-Vihār through music and rāga',
    tags: ['Musician', 'Mystic', 'Bāṅke Bihārī'],
  },
  {
    id: 'dhruvdas',
    name: 'Śrī Dhruvdās',
    nameHindi: 'श्री ध्रुवदास',
    slug: 'dhruvdas',
    sampradayaId: 'harivanshi',
    period: '16th century CE',
    bio: 'Śrī Dhruvdās was a prominent saint-poet in the Rādhāvallabh tradition, known for his vast literary output and deep devotional insight. His works elaborate on the theology of Nitya-Vihār and the intimate pastimes of the Divine Couple in the groves of Vṛndāvan. He composed extensively in Brajbhāṣā, producing works that serve as both devotional poetry and theological commentary.',
    works: ['Nikunj Vilās', 'Bhāv Vilās', 'Ras Vilās'],
    theologicalEmphasis: 'Nikunj-Līlā, devotional poetry as theological revelation',
    tags: ['Poet', 'Rādhāvallabh', 'Nikunj-Līlā'],
  },
];

export const books: Book[] = [
  {
    id: 'hit-chatushti',
    title: 'Hit Catuṣṭī',
    titleHindi: 'हित चतुष्टी',
    slug: 'hit-chatushti',
    saintId: 'hit-harivansh',
    sampradayaId: 'harivanshi',
    description: 'The Hit Catuṣṭī is the foundational scripture of the Rādhāvallabh Sampradāya, consisting of 84 sacred verses composed by Śrī Hit Harivansh Mahāprabhu. These verses reveal the eternal, intimate pastimes (Nitya-Vihār) of Śrī Rādhā-Kṛṣṇa in the groves of Vṛndāvan. The work is divided into four parts, each illuminating a different dimension of divine love.',
    language: 'Brajbhāṣā',
    structure: 'Four sections (Catuṣṭī), 84 verses total',
    vaniCount: 84,
    tags: ['Foundational', 'Liturgical', 'Nitya-Vihār'],
  },
  {
    id: 'kelimal',
    title: 'Kelimāl',
    titleHindi: 'केलिमाल',
    slug: 'kelimal',
    saintId: 'swami-haridas',
    sampradayaId: 'haridasi',
    description: 'The Kelimāl is the primary devotional work of Svāmī Haridās, containing verses that describe the divine play of the Supreme Couple with extraordinary aesthetic beauty. Composed in Brajbhāṣā and set to classical rāgas, these verses are meant to be sung as offerings of devotional rapture.',
    language: 'Brajbhāṣā',
    structure: 'Collection of padas (devotional verses)',
    vaniCount: 110,
    tags: ['Musical', 'Devotional', 'Rāga'],
  },
  {
    id: 'nikunj-vilas',
    title: 'Nikunj Vilās',
    titleHindi: 'निकुंज विलास',
    slug: 'nikunj-vilas',
    saintId: 'dhruvdas',
    sampradayaId: 'harivanshi',
    description: 'Nikunj Vilās is a masterwork by Śrī Dhruvdās that unfolds the intimate pastimes of the Divine Couple within the sacred groves (Nikunj) of Vṛndāvan. Each vānī is a window into the eternal play, rendered in luminous Brajbhāṣā poetry.',
    language: 'Brajbhāṣā',
    structure: 'Sequential vānīs describing Nikunj-Līlā',
    vaniCount: 200,
    tags: ['Nikunj-Līlā', 'Poetry', 'Brajbhāṣā'],
  },
];

export const vanis: Vani[] = [
  {
    id: 'hc-1',
    bookId: 'hit-chatushti',
    vaniNumber: 1,
    title: 'Maṅgalācaraṇa',
    titleHindi: 'मंगलाचरण',
    originalText: 'राधा सर्वसु साम्प्रदायिक धुरीण सर्वस्व सम्प्रदायाधिपति,\nश्री हित हरिवंश चन्द्र चरणारविन्द मकरन्द मधुकरायित मानसम् ।',
    transliteration: 'Rādhā sarvasū sāmpradāyika dhurīṇa sarvasva sampradāyādhipati,\nŚrī Hit Harivansh Candra caraṇāravinda makaranda madhukarāyita mānasam.',
    englishTranslation: 'I bow to Śrī Rādhā, the supreme presiding deity of all devotional traditions, and I offer my mind like a bee drawn to the nectar-lotus of the feet of Śrī Hit Harivansh Candra, the moon of our sacred lineage.',
    commentary: 'This opening verse (Maṅgalācaraṇa) establishes the theological foundation of the entire work. By placing Śrī Rādhā first and supreme, the author declares the Rādhā-centric nature of the tradition. The imagery of the bee and lotus echoes classical Sanskrit aesthetic conventions while grounding the devotee in contemplative absorption.',
    ras: 'Śānta',
    theme: 'Invocation',
    raga: 'Bhairav',
    tags: ['Maṅgalācaraṇa', 'Invocation', 'Rādhā'],
  },
  {
    id: 'hc-2',
    bookId: 'hit-chatushti',
    vaniNumber: 2,
    title: 'Nikunj Varṇana',
    titleHindi: 'निकुंज वर्णन',
    originalText: 'अति सुन्दर कुंज बिराजत, तहँ श्रीराधा-वल्लभ खेलत ।\nफूलन की सेज बिछावत, मधुर मुरली धुनि गावत ॥',
    transliteration: 'Ati sundara kuñja birājata, taham̐ Śrī Rādhā-Vallabha khelata.\nPhūlana kī seja bichāvata, madhura muralī dhuni gāvata.',
    englishTranslation: 'In the most beautiful grove They preside — Śrī Rādhā-Vallabha at play. A bed of flowers is spread, and the sweet melody of the flute resounds.',
    commentary: 'This vānī introduces the sacred grove (Nikunj) as the eternal abode of the Divine Couple. The imagery of the flower-bed and the flute melody establishes the mood of intimate divine play that permeates the entire work.',
    ras: 'Śṛṅgāra',
    theme: 'Nikunj-Līlā',
    raga: 'Kāmod',
    tags: ['Nikunj', 'Vṛndāvan', 'Flute'],
  },
  {
    id: 'hc-3',
    bookId: 'hit-chatushti',
    vaniNumber: 3,
    title: 'Rādhā Māhātmya',
    titleHindi: 'राधा माहात्म्य',
    originalText: 'श्री राधा सब सखिन शिरोमनि, प्रेम रसिक सिरताज ।\nवृन्दावन की अधिष्ठात्री, निकुंजन की महाराज ॥',
    transliteration: 'Śrī Rādhā saba sakhina śiromaṇi, prema rasika siratāja.\nVṛndāvana kī adhiṣṭhātrī, nikuñjana kī mahārāja.',
    englishTranslation: 'Śrī Rādhā is the crown-jewel among all sakhīs, the supreme sovereign of divine love. She is the presiding deity of Vṛndāvan, the sovereign of the sacred groves.',
    commentary: 'This verse establishes the supremacy of Śrī Rādhā — not merely as a devotee of Kṛṣṇa but as the supreme sovereign of the devotional realm. The term "Mahārāja" applied to Rādhā is theologically significant, affirming Her absolute authority.',
    ras: 'Mādhurya',
    theme: 'Rādhā Supremacy',
    tags: ['Rādhā', 'Supremacy', 'Theology'],
  },
  {
    id: 'km-1',
    bookId: 'kelimal',
    vaniNumber: 1,
    title: 'Bihārī Saundarya',
    titleHindi: 'बिहारी सौन्दर्य',
    originalText: 'मैं तो साँवरे के रंग रँची ।\nबिहारी लाल की छबि निरखत, अखियाँ अटकी कँची ॥',
    transliteration: 'Maiṁ to sām̐vare ke raṅga ram̐chī.\nBihārī Lāla kī chabi nirakhata, akhiyām̐ aṭakī kam̐chī.',
    englishTranslation: 'I am dyed in the colour of the Dark One. Beholding the beauty of Bihārī Lāl, my eyes have been caught like glass.',
    commentary: 'Svāmī Haridās opens with a declaration of complete absorption in divine beauty. The metaphor of being "dyed" suggests a permanent transformation — devotion is not a passing mood but an indelible change in the very being of the devotee.',
    ras: 'Śṛṅgāra',
    theme: 'Divine Beauty',
    raga: 'Darbārī Kānaḍā',
    tags: ['Beauty', 'Absorption', 'Bihārī'],
  },
  {
    id: 'km-2',
    bookId: 'kelimal',
    vaniNumber: 2,
    title: 'Rāga Vilāsa',
    titleHindi: 'राग विलास',
    originalText: 'आजु राग रस भीनी, श्री राधा-माधव केलि अनन्त ।\nसुर तार माँहि गुंजत, अमृत वाणी परम अनन्त ॥',
    transliteration: 'Āju rāga rasa bhīnī, Śrī Rādhā-Mādhava keli ananta.\nSura tāra mām̐hi guñjata, amṛta vāṇī parama ananta.',
    englishTranslation: 'Today is drenched in the rasa of rāga — the eternal play of Śrī Rādhā-Mādhava. Within the notes and strings resounds the nectarean speech, supremely infinite.',
    commentary: 'This pada unites music and theology seamlessly. Rāga is not merely a musical form but a mode of divine experience — the aesthetic vehicle through which the eternal play is both expressed and experienced.',
    ras: 'Śṛṅgāra',
    theme: 'Music and Divine Play',
    raga: 'Māl Kauṁsa',
    tags: ['Music', 'Rāga', 'Eternal Play'],
  },
  {
    id: 'km-3',
    bookId: 'kelimal',
    vaniNumber: 3,
    title: 'Kuñja Keli',
    titleHindi: 'कुंज केलि',
    originalText: 'कुंज महल में किलकत, दोउ जगत आनन्द कन्द ।\nश्री हरिदास के स्वामी, श्यामा-कुंजबिहारी चन्द ॥',
    transliteration: 'Kuñja mahala meṁ kilakata, dou jagata ānanda kanda.\nŚrī Haridāsa ke svāmī, Śyāmā-Kuñjabihārī canda.',
    englishTranslation: 'In the palace of the grove They rejoice — the two who are the root of all cosmic bliss. The Lord of Śrī Haridās, the moon-like Śyāmā-Kuñjabihārī.',
    commentary: 'The "palace of the grove" (Kuñja Mahal) is the innermost sanctum of the eternal realm. The Divine Couple is described as the source (kanda) of all bliss in existence — not just spiritual bliss but the very principle of joy itself.',
    ras: 'Mādhurya',
    theme: 'Nikunj-Līlā',
    tags: ['Kuñja', 'Bliss', 'Divine Couple'],
  },
  {
    id: 'nv-1',
    bookId: 'nikunj-vilas',
    vaniNumber: 1,
    title: 'Nikunj Praveśa',
    titleHindi: 'निकुंज प्रवेश',
    originalText: 'निकुंज द्वार पर ठाढ़ी, श्री राधिका जू महारानी ।\nमुस्कानि चितवत श्यामसुन्दर, कहत मधुर मुख बानी ॥',
    transliteration: 'Nikuñja dvāra para ṭhāḍhī, Śrī Rādhikā jū mahārānī.\nMuskāni citavata Śyāmasundara, kahata madhura mukha bānī.',
    englishTranslation: 'At the entrance of the sacred grove stands Śrī Rādhikā, the great sovereign. Smiling, She gazes at Śyāmasundara, speaking sweet words from Her lotus mouth.',
    commentary: 'This opening vānī of Nikunj Vilās sets the scene at the threshold of the grove. Rādhā stands as the sovereign — the grove is Her domain, and it is She who grants entry into the intimate realm of eternal play.',
    ras: 'Śṛṅgāra',
    theme: 'Nikunj-Līlā',
    tags: ['Entrance', 'Rādhā', 'Grove'],
  },
  {
    id: 'nv-2',
    bookId: 'nikunj-vilas',
    vaniNumber: 2,
    title: 'Śṛṅgāra Vilāsa',
    titleHindi: 'शृंगार विलास',
    originalText: 'सोने की पालना झुलावत, राधा-माधव दोउ ।\nहीरा मोती जड़ित सिंहासन, ऐसो न देख्यो कोउ ॥',
    transliteration: 'Sone kī pālanā jhulāvata, Rādhā-Mādhava dou.\nHīrā motī jaṛita siṁhāsana, aiso na dekhyo kou.',
    englishTranslation: 'On a golden swing They rock — both Rādhā and Mādhava. A throne studded with diamonds and pearls — none has ever seen such a sight.',
    commentary: 'The golden swing (Hindolā) is an iconic image in Rasik literature, symbolizing the playful, rhythmic nature of divine love. The jeweled throne signifies the supreme sovereignty of the Divine Couple over all realms.',
    ras: 'Śṛṅgāra',
    theme: 'Divine Play',
    raga: 'Hindol',
    tags: ['Swing', 'Golden', 'Sovereignty'],
  },
  {
    id: 'nv-3',
    bookId: 'nikunj-vilas',
    vaniNumber: 3,
    title: 'Sakhī Sevā',
    titleHindi: 'सखी सेवा',
    originalText: 'सखियन संग विराजत, श्री जू युगल सरकार ।\nचँवर ढुरावत ललिता, विशाखा करत सिंगार ॥',
    transliteration: 'Sakhiyana saṅga virājata, Śrī jū yugala sarakāra.\nCam̐vara ḍhurāvata Lalitā, Viśākhā karata siṅgāra.',
    englishTranslation: 'Amidst the sakhīs the Divine Couple presides. Lalitā waves the royal fan, while Viśākhā adorns Them.',
    commentary: 'The sakhī-sevā (service of the intimate companions) is a central concept in Rasik theology. The sakhīs are not mere attendants but are essential participants in the divine play, each with a unique relationship to the Divine Couple.',
    ras: 'Dāsya-Sakhya',
    theme: 'Sakhī-Sevā',
    tags: ['Sakhī', 'Service', 'Lalitā', 'Viśākhā'],
  },
  {
    id: 'nv-4',
    bookId: 'nikunj-vilas',
    vaniNumber: 4,
    title: 'Yamunā Tīra',
    titleHindi: 'यमुना तीर',
    originalText: 'यमुना तट पर बिराजत, श्री राधा-माधव जोरी ।\nचन्दन शीतल पवन बहत, निशि जागत प्रेम की डोरी ॥',
    transliteration: 'Yamunā taṭa para birājata, Śrī Rādhā-Mādhava jorī.\nCandana śītala pavana bahata, niśi jāgata prema kī ḍorī.',
    englishTranslation: 'On the banks of the Yamunā the Divine Couple is seated. A cool sandalwood-scented breeze blows, and through the night the thread of love remains awake.',
    commentary: 'The Yamunā bank is one of the sacred loci of divine play. The "thread of love" (Prema kī Ḍorī) that remains "awake through the night" points to the unbroken nature of divine love — it knows no interruption, no sleep, no end.',
    ras: 'Śṛṅgāra',
    theme: 'Yamunā-Līlā',
    raga: 'Yaman',
    tags: ['Yamunā', 'Night', 'Eternal Love'],
  },
];

// Helper functions
export function getSampradaya(id: string) {
  return sampradayas.find(s => s.id === id);
}

export function getSampradayaBySlug(slug: string) {
  return sampradayas.find(s => s.slug === slug);
}

export function getSaint(id: string) {
  return saints.find(s => s.id === id);
}

export function getSaintBySlug(slug: string) {
  return saints.find(s => s.slug === slug);
}

export function getSaintsBySampradaya(sampradayaId: string) {
  return saints.filter(s => s.sampradayaId === sampradayaId);
}

export function getBook(id: string) {
  return books.find(b => b.id === id);
}

export function getBookBySlug(slug: string) {
  return books.find(b => b.slug === slug);
}

export function getBooksBySaint(saintId: string) {
  return books.filter(b => b.saintId === saintId);
}

export function getBooksBySampradaya(sampradayaId: string) {
  return books.filter(b => b.sampradayaId === sampradayaId);
}

export function getVanisByBook(bookId: string) {
  return vanis.filter(v => v.bookId === bookId).sort((a, b) => a.vaniNumber - b.vaniNumber);
}

export function getVani(bookId: string, vaniNumber: number) {
  return vanis.find(v => v.bookId === bookId && v.vaniNumber === vaniNumber);
}

export function searchContent(query: string) {
  const q = query.toLowerCase();
  const results: { type: string; title: string; url: string; snippet: string }[] = [];

  saints.forEach(s => {
    if (s.name.toLowerCase().includes(q) || s.nameHindi.includes(q) || s.bio.toLowerCase().includes(q)) {
      results.push({ type: 'Saint', title: s.name, url: `/saint/${s.slug}`, snippet: s.bio.slice(0, 120) + '…' });
    }
  });

  books.forEach(b => {
    if (b.title.toLowerCase().includes(q) || b.titleHindi.includes(q) || b.description.toLowerCase().includes(q)) {
      results.push({ type: 'Book', title: b.title, url: `/book/${b.slug}`, snippet: b.description.slice(0, 120) + '…' });
    }
  });

  vanis.forEach(v => {
    const book = getBook(v.bookId);
    if (
      v.englishTranslation.toLowerCase().includes(q) ||
      v.originalText.includes(q) ||
      v.title.toLowerCase().includes(q) ||
      v.theme.toLowerCase().includes(q)
    ) {
      results.push({
        type: 'Vānī',
        title: `${book?.title} — Vānī ${v.vaniNumber}`,
        url: `/book/${book?.slug}/vani/${v.vaniNumber}`,
        snippet: v.englishTranslation.slice(0, 120) + '…',
      });
    }
  });

  return results;
}
